let estado = "inicio";
let pontuacao = 0;
let tempoLimite = 120000;
let tempoInicio;
let itens = [];
let obstaculos = [];
let caminhão;
let larguraBarra = 300;

let itensColetados = 0;
let velocidadeAtual = 2;
let velocidadeObstaculo = 3;
let nivelVelocidadeAtual = 0;
let tempoAviso = 0;
let mostrarAviso = false;
let tempoVitoria = null;
let tempoInicioFrame = 0;
let yTrofeu = -50;

function setup() {
  createCanvas(800, 400);
  textAlign(CENTER, CENTER);
  caminhão = new Caminhao();
  tempoInicioFrame = millis();
}

function draw() {
  background(255);

  if (estado === "inicio") telaInicial();
  else if (estado === "instrucoes") telaInstrucoes();
  else if (estado === "pontuacoes") telaPontuacoes();
  else if (estado === "jogo") telaJogo();
  else if (estado === "vitoria") telaVitoria();
  else if (estado === "derrota") telaDerrota();
  else if (estado === "tempoEsgotado") telaTempoEsgotado();
}

function telaInicial() {
  background("#ffc0cb");
  textSize(36);
  fill(0);
  text("🌽📱 Conexão Campo-Cidade 🎉", width / 2, height / 2 - 40);
  textSize(18);
  text("Clique para começar", width / 2, height / 2 + 40);
}

function telaInstrucoes() {
  background(240);
  textSize(16);
  fill(0);
  text("Use ← → para mover o caminhão.\n\n" +
       "Pegue alimentos no campo (🌽🥕🍎🍓) e leve ao mercado 🏪.\n" +
       "Pegue itens da cidade (📱👕) e leve para a casa 🏡.\n" +
       "Desvie dos obstáculos: campo = 🐄, cidade = 🚗\n" +
       "Entregue 16 pontos em 2 minutos.", width / 2, height / 2);
  text("Clique para ver os valores dos itens.", width / 2, height - 40);
}

function telaPontuacoes() {
  background(230);
  textAlign(LEFT, CENTER);
  textSize(12);
  text("💰 Pontuação por item:\n\n" +
       "🌽 = 2 pontos\n" +
       "🥕 = 3 pontos\n" +
       "🍎 = 1 ponto\n" +
       "🍓 = 6 pontos\n" +
       "📱 = 4 pontos\n" +
       "👕 = 5 pontos\n" +
       "\n🐄 = -4 pontos\n🚗 = -2 pontos", 80, height / 2 - 40);

  textAlign(CENTER, CENTER);
  textSize(16);
  text("Clique para começar o jogo.", width / 2, height - 40);
}

function telaJogo() {
  fill("green"); rect(0, 0, width / 2, height);
  fill("gray");  rect(width / 2, 0, width / 2, height);
  textSize(32);
  text("🏡", 60, height - 60);
  text("🏪", width - 60, height - 60);

  caminhão.mostrar();
  caminhão.mover();

  if (caminhão.itemCarregado) {
    textSize(24);
    text(caminhão.itemCarregado.emoji, caminhão.x, height - 80);

    let alvo = caminhão.itemCarregado.campo ? width - 60 : 60;
    let distAtual = abs(caminhão.x - alvo);
    let progresso = constrain(1 - distAtual / (width / 2), 0, 1);
    fill("blue");
    rect(caminhão.x - 20, height - 95, 40 * progresso, 6);
    noFill(); stroke(0); rect(caminhão.x - 20, height - 95, 40, 6);
  }

  for (let i = itens.length - 1; i >= 0; i--) {
    let item = itens[i];
    item.mostrar();
    item.mover();
    if (!caminhão.itemCarregado && item.pego(caminhão)) {
      caminhão.itemCarregado = item;
      itens.splice(i, 1);
      itensColetados++;
    }
  }

  if (caminhão.itemCarregado) {
    let alvo = caminhão.itemCarregado.campo ? width - 100 : 100;
    if ((caminhão.itemCarregado.campo && caminhão.x > alvo) ||
        (!caminhão.itemCarregado.campo && caminhão.x < alvo)) {
      pontuacao += caminhão.itemCarregado.pontos;
      caminhão.itemCarregado = null;
    }
  }

  for (let i = obstaculos.length - 1; i >= 0; i--) {
    let obs = obstaculos[i];
    obs.mostrar();
    obs.mover();
    if (obs.colidiu(caminhão)) {
      pontuacao -= obs.pontos;
      obstaculos.splice(i, 1);
    }
  }

  if (frameCount % 20 === 0) {
    if (random() < 0.6) {
      itens.push(new Item());
      if (random() < 0.3) itens.push(new Item());
    } else {
      obstaculos.push(new Obstaculo());
    }
  }

  let tempoDecorrido = millis() - tempoInicio;
  let incremento = floor(tempoDecorrido / 15000);
  if (incremento > nivelVelocidadeAtual) {
    nivelVelocidadeAtual = incremento;
    tempoAviso = millis();
    mostrarAviso = true;
  }
  velocidadeAtual = 2 + nivelVelocidadeAtual * 0.5;
  velocidadeObstaculo = 3 + nivelVelocidadeAtual * 0.5;

  fill(0);
  textSize(16);
  text("Pontuação: " + pontuacao, width - 100, 20);
  text("Itens coletados: " + itensColetados, width - 100, 40);

  if (mostrarAviso && millis() - tempoAviso < 2000) {
    textSize(24);
    fill("red");
    text("🚀 Velocidade aumentou!", width / 2, 60);
  } else {
    mostrarAviso = false;
  }

  mostrarBarraTempo();

  if (pontuacao >= 16) {
    estado = "vitoria";
    tempoVitoria = millis() - tempoInicio;
    yTrofeu = -50;
  } else if (pontuacao < 0) {
    estado = "derrota";
  }

  if (millis() - tempoInicio >= tempoLimite) estado = "tempoEsgotado";
}

function mostrarBarraTempo() {
  let tempoRestante = tempoLimite - (millis() - tempoInicio);
  let proporcao = constrain(tempoRestante / tempoLimite, 0, 1);
  fill("blue");
  rect(20, 10, proporcao * larguraBarra, 15);
  noFill(); stroke(0); rect(20, 10, larguraBarra, 15);
}

function telaVitoria() {
  background("#add8e6");
  textSize(20);
  text("🎉 Você venceu! 🎉", width / 2, height / 2 - 20);
  textSize(16);
  text("A conexão entre campo e cidade é essencial para todos!", width / 2, height / 2 + 10);

  if (tempoVitoria !== null && tempoVitoria < 60000) {
    let destinoY = height / 2 - 70;
    yTrofeu = lerp(yTrofeu, destinoY, 0.1);
    let t = (millis() - tempoInicioFrame) / 300;
    let escala = 1 + 0.1 * sin(t);

    push();
    translate(width / 2, yTrofeu);
    scale(escala);
    textSize(40);
    fill(255, 215, 0, 200); text("🏆", 2, 2);
    fill(0); text("🏆", 0, 0);
    pop();

    textSize(16);
    text("Vitória rápida!", width / 2, yTrofeu + 30);
  }

  if (tempoVitoria !== null) {
    text("Tempo total: " + formatarTempo(tempoVitoria), width / 2, height / 2 + 50);
  }
  text("Clique para voltar ao início.", width / 2, height / 2 + 80);
}

function formatarTempo(ms) {
  let totalSegundos = floor(ms / 1000);
  let minutos = floor(totalSegundos / 60);
  let segundos = totalSegundos % 60;
  return nf(minutos, 2) + ":" + nf(segundos, 2);
}

function telaDerrota() {
  background("#ffcccc");
  textSize(20);
  text("😢 Você perdeu! 😢", width / 2, height / 2 - 20);
  textSize(16);
  text("Clique para tentar novamente.", width / 2, height / 2 + 20);
}

function telaTempoEsgotado() {
  background("orange");
  textSize(20);
  text("⏳ Tempo esgotado!", width / 2, height / 2 - 20);
  textSize(16);
  text("Você não conseguiu 16 pontos em 2 minutos.\nClique para tentar novamente!", width / 2, height / 2 + 20);
}

function mousePressed() {
  if (estado === "inicio") estado = "instrucoes";
  else if (estado === "instrucoes") estado = "pontuacoes";
  else if (estado === "pontuacoes") {
    estado = "jogo";
    pontuacao = 0;
    itens = [];
    obstaculos = [];
    caminhão.itemCarregado = null;
    tempoInicio = millis();
    tempoInicioFrame = millis();
    itensColetados = 0;
    velocidadeAtual = 2;
    velocidadeObstaculo = 3;
    nivelVelocidadeAtual = 0;
    tempoAviso = 0;
    mostrarAviso = false;
    tempoVitoria = null;
    yTrofeu = -50;
  }
  else if (estado === "vitoria" || estado === "derrota" || estado === "tempoEsgotado") {
    estado = "inicio";
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) caminhão.direcao = -1;
  if (keyCode === RIGHT_ARROW) caminhão.direcao = 1;
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) caminhão.direcao = 0;
}

class Caminhao {
  constructor() {
    this.x = width / 2;
    this.direcao = 0;
    this.itemCarregado = null;
  }
  mostrar() {
    textSize(32);
    text("🚛", this.x, height - 40);
  }
  mover() {
    this.x += this.direcao * 5;
    this.x = constrain(this.x, 20, width - 20);
  }
}

class Item {
  constructor() {
    this.x = random(width);
    this.y = -20;
    let tipos = [
      { emoji: "🌽", pontos: 2, campo: true },
      { emoji: "🥕", pontos: 3, campo: true },
      { emoji: "🍎", pontos: 1, campo: true },
      { emoji: "🍓", pontos: 6, campo: true },
      { emoji: "📱", pontos: 4, campo: false },
      { emoji: "👕", pontos: 5, campo: false },
    ];
    let escolhido = random(tipos);
    this.emoji = escolhido.emoji;
    this.pontos = escolhido.pontos;
    this.campo = escolhido.campo;
  }
  mostrar() {
    textSize(24);
    text(this.emoji, this.x, this.y);
  }
  mover() {
    this.y += velocidadeAtual;
  }
  pego(cam) {
    return dist(this.x, this.y, cam.x, height - 40) < 30;
  }
}

class Obstaculo {
  constructor() {
    let tipo;
    if (random() < 0.5) {
      tipo = { emoji: "🐄", pontos: 4 };
      this.x = random(0, width / 2 - 30);
    } else {
      tipo = { emoji: "🚗", pontos: 2 };
      this.x = random(width / 2 + 30, width);
    }
    this.emoji = tipo.emoji;
    this.pontos = tipo.pontos;
    this.y = -20;
  }
  mostrar() {
    textSize(24);
    text(this.emoji, this.x, this.y);
  }
  mover() {
    this.y += velocidadeObstaculo;
  }
  colidiu(cam) {
    return dist(this.x, this.y, cam.x, height - 40) < 30;
  }
}
